#!/usr/bin/env python3
import main
from main import connection
import cgi
import html

# Запись изображений в файл
def write_file(data, filename):
   with open(filename, 'wb') as f:
       f.write(data)

form = cgi.FieldStorage()
sub = form.getfirst("info", "постое значение")

sub = html.escape(sub)
print("Content-Type: text/html")  # Добавлен заголовок Content-Type для указания типа содержимого

print("""
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Информация о клиентах</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Список клиентов</h1>
    <table border=1>
        <tr>
            <th>Имя</th>
            <th>Фамилия</th>
            <th>Адрес</th>
            <th>Телефон</th>
        </tr>
""")

try:
    with connection.cursor() as cursor:
        select_clients = "SELECT * FROM `Client`"
        cursor.execute(select_clients)
        clients = cursor.fetchall()
        for client in clients:
            print("<tr>")
            print(f"<td>{client[3]}</td>")
            print(f"<td>{client[4]}</td>")
            print(f"<td>{client[5]}</td>")
            print(f"<td>{client[6]}</td>")
            print("</tr>")

finally:
    connection.close()

print("""
       </table>
   </body>
   </html>
""")
