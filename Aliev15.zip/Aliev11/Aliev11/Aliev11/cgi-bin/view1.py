from main import connection
import create_table
# Обработка исключений
try:
        with connection.cursor() as cursor:
            #создание таблицы Categ
            cursor.execute(create_table.create_table_client)
            connection.commit()
            #создание таблицы pets
            cursor.execute(create_table.create_table_bank)
            connection.commit()
            # создание таблицы pets
            cursor.execute(create_table.create_table_platez)
            connection.commit()
            #создание таблицы custom
            cursor.execute(create_table.insert_Client)
            connection.commit()
            #создание таблицы basket
            cursor.execute(create_table.insert_loan)
            connection.commit()
            cursor.execute(create_table.insert_Platez)
            connection.commit()


finally:
    connection.close()
