# Запросы на создание таблиц и вставку данных
create_table_client = "CREATE TABLE `Client` (id int AUTO_INCREMENT," \
                        "id_client int(32)," \
                        "id_Platez int," \
                        "last_name varchar(32)," \
                        "ferst_name varchar(32)," \
                        "adress varchar(32)," \
                        "phone varchar(32)," \
                        "PRIMARY KEY (id));"

create_table_bank = "CREATE TABLE `loan` (id int AUTO_INCREMENT," \
                     " id_client int," \
                     " summe int," \
                     " date_credit date," \
                     " date_pogashen date," \
                     " rate int," \
                     " PRIMARY KEY (id)," \
                     " FOREIGN KEY (id_client) REFERENCES Client(id));"

create_table_platez = "CREATE TABLE `Platez` (id int AUTO_INCREMENT," \
                       "id_client_sender int(32)," \
                       "id_loan int(32)," \
                       "date date," \
                       "summa int(32)," \
                       "phone varchar(32)," \
                       "PRIMARY KEY (id)," \
                       "FOREIGN KEY (id_loan) REFERENCES loan(id));"

insert_Client = "INSERT INTO `Client` (`id_client`, `id_Platez`, `last_name`, `ferst_name`, `adress`, `phone`) VALUES " \
                "(1, 1, 'Максим', 'Сорокин', 'Пушкинская', '79322424324')," \
                "(2, 2, 'Иван', 'Иванов', 'Пушкинская', '793224243212');"

insert_loan = "INSERT INTO `loan` (`id_client`, `summe`, `date_credit`, `date_pogashen`, `rate`) VALUES " \
              "(1, 100000, '2023-05-24', '2023-06-24', 5)," \
              "(2, 150000, '2023-05-05', '2023-05-30', 6);"

insert_Platez = "INSERT INTO `Platez` (`id_client_sender`, `id_loan`, `date`, `summa`, `phone`) VALUES " \
                "(1, 1, '2023-06-01', 45000, '79322424324')," \
                "(2, 2, '2023-05-20', 50000, '793224243212');"
