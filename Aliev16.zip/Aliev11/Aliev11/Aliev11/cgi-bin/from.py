#!/usr/bin/env python3
import main
from main import connection
import cgi
import html

form = cgi.FieldStorage()
name_c = form.getfirst("name_c", "постое значение")
x = int(name_c)


print("Content-Type: text/html")
print("""
<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <title>Информация о займай клиентов</title>
    <link rel='stylesheet' href='style.css'>
</head>
<body>
    <h1>Список клиентов</h1>
    <table border=1>
        <tr>
            <th>Дата займа</th>
            <th>Окончание займа</th>
            <th>Сумма займя</th>
        </tr>
""")

try:
    with connection.cursor() as cursor:
        select_clients = f"SELECT * FROM `loan` WHERE `id_client` = {x}"
        cursor.execute(select_clients)
        clients = cursor.fetchall()

        for client in clients:
            print("<tr>")
            print(f"<td>{client[3]}</td>")
            print(f"<td>{client[4]}</td>")
            print(f"<td>{client[2]}</td>")
            print("</tr>")

finally:
    connection.close()

print("""
       </table>
   </body>
   </html>
""")
