import main
from main import connection

try:
    with connection.cursor() as cursor:
        cursor.execute("SELECT * FROM `info_client`")
        view1 = cursor.fetchall()
        print("Информация клиентов:")
        for i in view1:
          print(f"Имя: {i[0]}, | Фамилия: {i[1]}, | Адресс: {i[2]}| , Телефон: {i[3]}")


        print("_" * 20)
finally:
    connection.close()


